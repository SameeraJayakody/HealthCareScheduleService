-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2020 at 10:57 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospitaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `aID` int(11) NOT NULL,
  `sessionDate` date NOT NULL,
  `sessionTime` time NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `paymentStatus` tinyint(4) DEFAULT 0,
  `patientID` int(11) DEFAULT NULL,
  `docID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `card`
--

CREATE TABLE `card` (
  `cardNo` char(16) NOT NULL,
  `paymentNo` int(11) NOT NULL,
  `cardHolderName` varchar(50) NOT NULL,
  `expiryDate` date NOT NULL,
  `cvv` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `docschedule`
--

CREATE TABLE `docschedule` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(11) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `docschedule`
--

INSERT INTO `docschedule` (`ID`, `scheduleID`, `HospitalName`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(156, 6, 'Durdans Hospital', 'Mr.Isuru Udana', 'Dermatologists', '2020/02/01', '09:30:am', '11:30:am', 150, 'YES'),
(190, 27, 'Asiri', 'Prasanna Jayathilaka', 'Eye', '2020/02/04', '12:30:pm', '03:30:pm', 23, 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `doctorconfirmation`
--

CREATE TABLE `doctorconfirmation` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(11) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctorconfirmation`
--

INSERT INTO `doctorconfirmation` (`ID`, `scheduleID`, `HospitalName`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(2, 2, 'ad', 'nmfl', 'ajaj', '2002', '12.30', '6.30', 111, 'no'),
(8, 44, 'addas', 'asd', 'adasd', '33', '44', '55', 133, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `doctorhospital`
--

CREATE TABLE `doctorhospital` (
  `ID` int(11) NOT NULL,
  `hospitalID` int(11) NOT NULL,
  `docID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctorhospital`
--

INSERT INTO `doctorhospital` (`ID`, `hospitalID`, `docID`) VALUES
(2, 22, 123);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `docID` int(11) NOT NULL,
  `hospitalID` int(11) NOT NULL,
  `docName` varchar(50) DEFAULT NULL,
  `docEmail` varchar(30) DEFAULT NULL,
  `docAddress` varchar(100) DEFAULT NULL,
  `specialization` varchar(50) DEFAULT NULL,
  `workingTime` varchar(20) DEFAULT NULL,
  `workingDays` varchar(100) DEFAULT NULL,
  `workingHospitals` varchar(100) DEFAULT NULL,
  `docFee` float DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`docID`, `hospitalID`, `docName`, `docEmail`, `docAddress`, `specialization`, `workingTime`, `workingDays`, `workingHospitals`, `docFee`, `username`, `password`) VALUES
(123, 22, 'Danushka', 'asd', 'ad', 'asd', 'asd', 'ads', 'asd', 125, 'asd', 'ads');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `hospitalID` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `phoneNo` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `code` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `hospitalFee` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`hospitalID`, `name`, `type`, `description`, `phoneNo`, `email`, `code`, `city`, `state`, `hospitalFee`) VALUES
(22, 'asc', 'asc', 'asc', 'asa', 'asd', 'asda', 'asd', 'asd', 22000.00);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `pID` int(11) NOT NULL,
  `pFname` varchar(50) NOT NULL,
  `pLname` varchar(50) NOT NULL,
  `pAge` int(11) NOT NULL,
  `pGender` varchar(12) NOT NULL,
  `pAddress` varchar(45) NOT NULL,
  `pContactNo` varchar(15) NOT NULL,
  `pNIC` varchar(12) NOT NULL,
  `pEmail` varchar(50) NOT NULL,
  `pUsername` varchar(50) NOT NULL,
  `pPassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentNo` int(11) NOT NULL,
  `amount` float NOT NULL,
  `paymentType` varchar(20) NOT NULL,
  `activeStatus` char(1) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `appointmentID` int(11) NOT NULL,
  `patientID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(6) NOT NULL,
  `DoctorID` varchar(5) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `Message` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `ID` int(11) NOT NULL,
  `scheduleID` int(6) NOT NULL,
  `HospitalID` varchar(5) NOT NULL,
  `HospitalName` varchar(70) NOT NULL,
  `DoctorID` varchar(5) NOT NULL,
  `DoctorName` varchar(70) NOT NULL,
  `Speciality` varchar(70) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `StartTime` varchar(8) NOT NULL,
  `EndTime` varchar(8) NOT NULL,
  `RoomNumber` int(5) NOT NULL,
  `Status` char(3) NOT NULL DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`ID`, `scheduleID`, `HospitalID`, `HospitalName`, `DoctorID`, `DoctorName`, `Speciality`, `Date`, `StartTime`, `EndTime`, `RoomNumber`, `Status`) VALUES
(6, 400400, '001HP', 'Nawaloka Hospital', '002AH', 'Mr.Isuru Udana', 'Ent And Neck Surgeon', '2020-05-20', '02:02', '06:01', 150, 'YES'),
(27, 524402, '511HP', 'Asiri Hospital', '004AH', 'Prasanna Jayathilaka', 'Neurologist', '2020-05-15', '02:02', '07:01', 23, 'YES'),
(41, 123456, '190HP', 'Lanka Hospital', '113AH', 'Kalana Perera ', 'Anaesthesiologist', '2020-05-05', '01:00', '03:00', 58, 'NO'),
(82, 112233, '009HP', 'Lanka Hospital', '011AH', 'Nimal Fernando', 'Hepatologists', '05-12-2020', '08:00:PM', '10:00:PM', 50, 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`aID`),
  ADD KEY `fk_patientapp` (`patientID`),
  ADD KEY `fk_doctorapp` (`docID`);

--
-- Indexes for table `card`
--
ALTER TABLE `card`
  ADD PRIMARY KEY (`cardNo`),
  ADD KEY `paymentNo` (`paymentNo`);

--
-- Indexes for table `docschedule`
--
ALTER TABLE `docschedule`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `scheduleID` (`scheduleID`);

--
-- Indexes for table `doctorconfirmation`
--
ALTER TABLE `doctorconfirmation`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `scheduleID_2` (`scheduleID`),
  ADD KEY `scheduleID_3` (`scheduleID`);

--
-- Indexes for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `hospitalID` (`hospitalID`),
  ADD UNIQUE KEY `docID` (`docID`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`docID`),
  ADD KEY `hospitalID` (`hospitalID`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`hospitalID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentNo`),
  ADD KEY `fk_appointment` (`appointmentID`),
  ADD KEY `fk_patient` (`patientID`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `scheduleID` (`scheduleID`),
  ADD UNIQUE KEY `HospitalID` (`HospitalID`),
  ADD UNIQUE KEY `DoctorID` (`DoctorID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `aID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `docschedule`
--
ALTER TABLE `docschedule`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=191;

--
-- AUTO_INCREMENT for table `doctorconfirmation`
--
ALTER TABLE `doctorconfirmation`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `docID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `hospitalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `pID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `fk_doctorapp` FOREIGN KEY (`docID`) REFERENCES `doctors` (`docID`),
  ADD CONSTRAINT `fk_patientapp` FOREIGN KEY (`patientID`) REFERENCES `patient` (`pID`);

--
-- Constraints for table `card`
--
ALTER TABLE `card`
  ADD CONSTRAINT `card_ibfk_1` FOREIGN KEY (`paymentNo`) REFERENCES `payment` (`paymentNo`);

--
-- Constraints for table `docschedule`
--
ALTER TABLE `docschedule`
  ADD CONSTRAINT `docschedule_ibfk_1` FOREIGN KEY (`scheduleID`) REFERENCES `schedule` (`ID`);

--
-- Constraints for table `doctorhospital`
--
ALTER TABLE `doctorhospital`
  ADD CONSTRAINT `doctorhospital_ibfk_1` FOREIGN KEY (`docID`) REFERENCES `doctors` (`docID`),
  ADD CONSTRAINT `doctorhospital_ibfk_2` FOREIGN KEY (`hospitalID`) REFERENCES `hospital` (`hospitalID`);

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`hospitalID`) REFERENCES `hospital` (`hospitalID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `fk_appointment` FOREIGN KEY (`appointmentID`) REFERENCES `appointment` (`aID`),
  ADD CONSTRAINT `fk_patient` FOREIGN KEY (`patientID`) REFERENCES `patient` (`pID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
